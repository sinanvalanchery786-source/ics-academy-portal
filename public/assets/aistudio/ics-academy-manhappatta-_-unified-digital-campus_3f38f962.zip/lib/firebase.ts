export {
  app,
  db,
  auth,
  storage,
  testConnection,
  OperationType,
  type FirestoreErrorInfo,
  handleFirestoreError,
  signInWithGoogle,
  signOutFirebase,
} from '../src/lib/firebase'
