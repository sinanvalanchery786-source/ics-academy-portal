import { initializeApp, getApps, getApp } from 'firebase/app'
import {
  getAuth,
  GoogleAuthProvider,
  inMemoryPersistence,
  initializeAuth,
  signInWithPopup,
  signOut as firebaseSignOut,
  type Auth,
} from 'firebase/auth'
import { doc, getDocFromServer, getFirestore } from 'firebase/firestore'
import { getStorage } from 'firebase/storage'
import firebaseConfig from '../../firebase-applet-config.json'

// Purge any stale cached Firebase Auth tokens in browser storage that could trigger
// securetoken.googleapis.com token-refresh failures when Token Service API is disabled.
if (typeof window !== 'undefined') {
  try {
    const keysToRemove: string[] = []
    for (let i = 0; i < window.localStorage.length; i++) {
      const key = window.localStorage.key(i)
      if (key && key.startsWith('firebase:')) {
        keysToRemove.push(key)
      }
    }
    for (const key of keysToRemove) {
      window.localStorage.removeItem(key)
    }
  } catch {
    // Ignore localStorage access errors
  }

  try {
    if ('indexedDB' in window && typeof window.indexedDB?.deleteDatabase === 'function') {
      window.indexedDB.deleteDatabase('firebaseLocalStorageDb')
    }
  } catch {
    // Ignore indexedDB access errors
  }
}

// Primary Firebase app dedicated to Firestore and Storage so Firestore's transport
// never blocks on a stale Auth token refresh against securetoken.googleapis.com.
export const app = getApps().some((a) => a.name === '[DEFAULT]')
  ? getApp()
  : initializeApp(firebaseConfig)

export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId)
export const storage = getStorage(app, firebaseConfig.storageBucket)

// Isolated Firebase app for Auth with inMemoryPersistence so stale IndexedDB sessions
// are never restored on boot.
const AUTH_APP_NAME = 'ics-auth-client'
const authApp = getApps().some((a) => a.name === AUTH_APP_NAME)
  ? getApp(AUTH_APP_NAME)
  : initializeApp(firebaseConfig, AUTH_APP_NAME)

function createIsolatedAuth(): Auth {
  try {
    return initializeAuth(authApp, {
      persistence: inMemoryPersistence,
    })
  } catch {
    return getAuth(authApp)
  }
}

export const auth = createIsolatedAuth()

export async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'))
  } catch (error) {
    if (error instanceof Error) {
      const code = (error as { code?: string }).code ?? 'unknown'
      // Only log unexpected errors, ignoring transient offline states during initial boot
      if (!error.message.includes('the client is offline')) {
        console.warn(`Firebase connection check notice [${code}]: ${error.message}`)
      }
    }
  }
}

if (typeof window !== 'undefined') {
  void testConnection()
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string
  operationType: OperationType
  path: string | null
  authInfo: {
    userId?: string | null
    email?: string | null
    emailVerified?: boolean | null
    isAnonymous?: boolean | null
    tenantId?: boolean | string | null
    providerInfo?: {
      providerId?: string | null
      email?: string | null
    }[]
  }
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo))
  throw new Error(JSON.stringify(errInfo))
}

export async function signInWithGoogle() {
  const provider = new GoogleAuthProvider()
  provider.setCustomParameters({ prompt: 'select_account' })
  return signInWithPopup(auth, provider)
}

export async function signOutFirebase() {
  return firebaseSignOut(auth)
}
