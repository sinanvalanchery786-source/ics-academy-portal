'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import { onAuthStateChanged, type User as FirebaseUser } from 'firebase/auth'
import { doc, serverTimestamp, setDoc } from 'firebase/firestore'
import {
  Bookmark,
  BookmarkCheck,
  BookOpen,
  Bot,
  Check,
  Compass,
  Copy,
  GraduationCap,
  Languages,
  Loader2,
  MessageSquareText,
  RotateCcw,
  Send,
  Sparkles,
  User,
  Zap,
} from 'lucide-react'
import type { Student } from '@/components/dashboard/data'
import { Panel, fieldClassName } from '@/components/dashboard/panel'
import { Button } from '@/components/ui/button'
import {
  auth,
  db,
  handleFirestoreError,
  OperationType,
} from '@/src/lib/firebase'
import { cn } from '@/lib/utils'

export type ChatRole = 'usthad' | 'academic' | 'language' | 'campus'
export type ChatLanguage = 'ml' | 'en' | 'ar'
export type ChatModelTier = 'flash' | 'flash-lite'

export interface ChatTurnMessage {
  id: string
  role: 'user' | 'model'
  text: string
  timestamp: number
  modelUsed?: string
  persona?: ChatRole
}

const PERSONAS: {
  id: ChatRole
  title: string
  malayalamTitle: string
  badge: string
  icon: typeof BookOpen
  description: string
  welcomeMessage: string
  starters: { label: string; prompt: string }[]
}[] = [
  {
    id: 'usthad',
    title: 'Usthad Kitab Mentor',
    malayalamTitle: 'കിതാബ് & ഫിഖ്ഹ് ഗുരു',
    badge: 'Kitab · Fiqh · Nahw',
    icon: BookOpen,
    description:
      'Multi-turn scholarly dialogue on Fathul Mueen, Mahalli, Tafsir Jalalayn, Alfiyyah, and Shafi\'i Fiqh.',
    welcomeMessage:
      'അസ്സലാമു അലൈക്കും! ഞാൻ ഐ.സി.എസ് അക്കാദമി മഞ്ഞപ്പറ്റയുടെ (Da\'wa College) കിതാബ് & ഫിഖ്ഹ് മെന്റർ ചാറ്റ്ബോട്ടാണ്. ഫത്ഹുൽ മുഈൻ, മഹല്ലി, അൽഫിയ്യ, തഫ്സീർ, നഹ്‌വ്-സർഫ് വിഷയങ്ങളിൽ തുടർച്ചയായ സംഭാഷണത്തിലൂടെ സംശയങ്ങൾ ചോദിക്കാം.',
    starters: [
      {
        label: 'ഫത്ഹുൽ മുഈൻ — തയമ്മും നിബന്ധനകൾ',
        prompt:
          'ശാഫിഈ മദ്ഹബ് പ്രകാരം തയമ്മും സ്വഹീറാകാനുള്ള പ്രധാന നിബന്ധനകൾ എന്തൊക്കെയാണ്? തുടർന്ന് എന്നോട് ഒരു ചെറിയ ചോദ്യം ചോദിക്കാമോ?',
      },
      {
        label: 'ഇഅ്റാബ് (I\'rab) സംഭാഷണത്തിലൂടെ പഠിക്കാം',
        prompt:
          '"الْعِلْمُ نُورٌ يَقْذِفُهُ اللَّهُ فِي الْقَلْبِ" — ഈ വാചകത്തിന്റെ ഇഅ്റാബും നഹ്‌വ് നിയമങ്ങളും ഘട്ടം ഘട്ടമായി വിശദീകരിക്കാമോ?',
      },
      {
        label: 'ഉസൂലുൽ ഫിഖ്ഹ് — ആം (Aam) & ഖാസ് (Khas)',
        prompt:
          'ഉസൂലുൽ ഫിഖ്ഹിലെ ആം (العام), ഖാസ് (الخاص) എന്നിവ തമ്മിലുള്ള വ്യത്യാസം ഉദാഹരണസഹിതം വിശദീകരിക്കുക.',
      },
    ],
  },
  {
    id: 'academic',
    title: 'Academic & Exam Tutor',
    malayalamTitle: 'പരീക്ഷാ & അക്കാദമിക് ഗൈഡ്',
    badge: 'Exams · Degree · Plus Two',
    icon: GraduationCap,
    description:
      'Interactive revision, exam-ready notes, and Socratic tutoring across Humanities, History, English, and Islamic Studies.',
    welcomeMessage:
      'സ്വാഗതം! പരീക്ഷാ തയ്യാറെടുപ്പുകൾക്കും അക്കാദമിക് വിഷയങ്ങൾക്കും (Humanities, History, English, Islamic History) വേണ്ടിയുള്ള മൾട്ടി-ടേൺ ട്യൂട്ടർ ആണിത്. ഏത് വിഷയമാണ് ഇന്ന് നമുക്ക് ഒരുമിച്ച് റിവൈസ് ചെയ്യേണ്ടത്?',
    starters: [
      {
        label: 'ഇസ്‌ലാമിക ചരിത്രം — അബ്ബാസി കാലഘട്ടം',
        prompt:
          'അബ്ബാസി ഖിലാഫത്തിന്റെ സുവർണ്ണ കാലഘട്ടത്തിലെ വൈജ്ഞാനിക മുന്നേറ്റങ്ങളെക്കുറിച്ച് (Bayt al-Hikmah) പരീക്ഷയ്ക്ക് എഴുതാൻ പറ്റിയ പോയിന്റുകൾ നൽകാമോ?',
      },
      {
        label: 'റിവിഷൻ ക്വിസ് തുടങ്ങാം (Interactive Quiz)',
        prompt:
          'കേരളത്തിലെ ഇസ്‌ലാമിക ചരിത്രവുമായി ബന്ധപ്പെട്ട് എന്നോട് 3 ചോദ്യങ്ങൾ ഒന്നിനുപുറകെ ഒന്നായി ചോദിച്ച് എന്റെ ഉത്തരങ്ങൾ വിലയിരുത്താമോ?',
      },
      {
        label: 'Essay Writing & Study Plan',
        prompt:
          'സെമസ്റ്റർ പരീക്ഷയ്ക്ക് കിതാബുകളും അക്കാദമിക് വിഷയങ്ങളും ഒരുമിച്ച് പഠിക്കാൻ ഒരു പ്രതിവാര സ്റ്റഡി പ്ലാൻ തയ്യാറാക്കി തരാമോ?',
      },
    ],
  },
  {
    id: 'language',
    title: 'Trilingual Coach',
    malayalamTitle: 'അറബിക് - ഇംഗ്ലീഷ് - മലയാളം',
    badge: 'Arabic · English · Malayalam',
    icon: Languages,
    description:
      'Practice Arabic conversation (Muhadathah), academic English, and trilingual translation with grammar feedback.',
    welcomeMessage:
      'أهلاً وسهلاً بك! നമുക്ക് അറബിക് സംഭാഷണം (المحادثة العربية), ഇംഗ്ലീഷ് ഭാഷാ നൈപുണ്യം, ത്രിഭാഷാ വിവർത്തനം എന്നിവ സംഭാഷണത്തിലൂടെ പരിശീലിക്കാം. ഏത് ഭാഷയിലാണ് തുടങ്ങേണ്ടത്?',
    starters: [
      {
        label: 'അറബിക് സംഭാഷണ പരിശീലനം (Muhadathah)',
        prompt:
          'ദഅ്‌വ കോളേജ് ലൈബ്രറിയിൽ വെച്ച് ഉസ്താദും വിദ്യാർത്ഥിയും തമ്മിലുള്ള ഒരു ചെറിയ അറബിക് സംഭാഷണം (മലയാളം അർത്ഥസഹിതം) തുടങ്ങാമോ?',
      },
      {
        label: 'അറബിക് മൂലപദങ്ങൾ (Root & Sarf)',
        prompt:
          '"استغفار" (Istighfar), "تعلّم" (Ta\'allum) എന്നീ പദങ്ങളുടെ മാദ്ദയും (Root) സർഫ് രൂപങ്ങളും വിശദീകരിക്കാമോ?',
      },
      {
        label: 'Academic English Practice',
        prompt:
          'Help me practice formal academic English for an inter-collegiate Da\'wa seminar presentation. Start by asking me about my topic.',
      },
    ],
  },
  {
    id: 'campus',
    title: "Campus & Da'wa Advisor",
    malayalamTitle: 'ക്യാമ്പസ് & ദഅ്‌വ സഹായി',
    badge: "Da'wa · Speech · Library",
    icon: Compass,
    description:
      'Speech preparation, Friday Khutbah structuring, Kitab reading recommendations, and campus routines.',
    welcomeMessage:
      'അസ്സലാമു അലൈക്കും! ദഅ്‌വ പ്രസംഗ പരിശീലനം, സാഹിത്യ സമാജം പ്രബന്ധങ്ങൾ, ഡിജിറ്റൽ ലൈബ്രറി കിതാബ് തിരഞ്ഞെടുപ്പ് എന്നിവയിൽ നിങ്ങളെ സഹായിക്കാൻ ഞാൻ തയ്യാറാണ്.',
    starters: [
      {
        label: 'സാഹിത്യ സമാജം പ്രസംഗ പരിശീലനം',
        prompt:
          'വരുന്ന വെള്ളിയാഴ്ച സാഹിത്യ സമാജത്തിൽ "വിദ്യാർത്ഥികളും സമയക്രമവും" എന്ന വിഷയത്തിൽ പ്രസംഗിക്കാൻ ആമുഖവും ഖുർആൻ-ഹദീസ് ഉദ്ധരണികളും നൽകാമോ?',
      },
      {
        label: 'വായിച്ചിരിക്കേണ്ട പ്രധാന കിതാബുകൾ',
        prompt:
          'ഒരു ദഅ്‌വ കോളേജ് വിദ്യാർത്ഥി നിർബന്ധമായും വായിച്ചിരിക്കേണ്ട 5 ക്ലാസിക്കൽ കിതാബുകളും അവയുടെ സവിശേഷതകളും പരിചയപ്പെടുത്താമോ?',
      },
    ],
  },
]

const LANGUAGES: { id: ChatLanguage; label: string }[] = [
  { id: 'ml', label: 'മലയാളം' },
  { id: 'en', label: 'English' },
  { id: 'ar', label: 'العربية' },
]

const MODEL_TIERS: {
  id: ChatModelTier
  label: string
  modelBadge: string
  description: string
  icon: typeof Sparkles
}[] = [
  {
    id: 'flash-lite',
    label: 'Gemini 3.1 Flash-Lite',
    modelBadge: 'gemini-3.1-flash-lite',
    description: 'Fast Instant Responses (~1.3s)',
    icon: Zap,
  },
  {
    id: 'flash',
    label: 'Gemini 3.8 Flash',
    modelBadge: 'gemini-3.8-flash',
    description: 'Deep Scholarly Tasks (Auto-fallback)',
    icon: Sparkles,
  },
]

const CHAT_STORAGE_KEY = 'ics_gemini_chat_threads_v1'

function sanitizeId(raw: string) {
  return raw.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 120) || `chat_${Date.now()}`
}

function renderSlantedWords(content: string, keyPrefix: string) {
  const parts = content.split(/(\s+)/)
  return parts.map((part, idx) => {
    if (!part) return null
    if (/^\s+$/.test(part)) {
      return <span key={`${keyPrefix}-ws-${idx}`}>{part}</span>
    }
    return (
      <span key={`${keyPrefix}-w-${idx}`} className="inline-block -skew-x-10">
        {part}
      </span>
    )
  })
}

function renderInlineMarkdown(line: string, keyPrefix: string, isUser: boolean) {
  const tokenRegex =
    /(\*\*\*[\s\S]+?\*\*\*|___[\s\S]+?___|\*\*[\s\S]+?\*\*|__[\s\S]+?__|\*[^\s*](?:[\s\S]*?[^\s*])?\*|_[^\s_](?:[\s\S]*?[^\s_])?_|\`[^\`]+\`)/g

  const nodes: React.ReactNode[] = []
  let lastIndex = 0
  let match: RegExpExecArray | null

  while ((match = tokenRegex.exec(line)) !== null) {
    if (match.index > lastIndex) {
      nodes.push(line.slice(lastIndex, match.index))
    }

    const token = match[0]
    const k = `${keyPrefix}-t-${match.index}`

    if ((token.startsWith('***') && token.endsWith('***')) || (token.startsWith('___') && token.endsWith('___'))) {
      const inner = token.slice(3, -3)
      nodes.push(
        <strong
          key={k}
          className={cn(
            'font-bold [font-synthesis:weight_style] [-webkit-text-stroke:0.35px_currentColor]',
            isUser ? 'text-primary-foreground' : 'text-foreground',
          )}
        >
          <em className="not-italic">{renderSlantedWords(inner, k)}</em>
        </strong>,
      )
    } else if ((token.startsWith('**') && token.endsWith('**')) || (token.startsWith('__') && token.endsWith('__'))) {
      const inner = token.slice(2, -2)
      nodes.push(
        <strong
          key={k}
          className={cn(
            'font-bold [font-synthesis:weight] [-webkit-text-stroke:0.35px_currentColor]',
            isUser ? 'text-primary-foreground' : 'text-foreground',
          )}
        >
          {inner}
        </strong>,
      )
    } else if ((token.startsWith('*') && token.endsWith('*')) || (token.startsWith('_') && token.endsWith('_'))) {
      const inner = token.slice(1, -1)
      nodes.push(
        <em
          key={k}
          className={cn(
            'not-italic [font-synthesis:style]',
            isUser ? 'text-primary-foreground/95' : 'text-lime/95',
          )}
        >
          {renderSlantedWords(inner, k)}
        </em>,
      )
    } else if (token.startsWith('`') && token.endsWith('`')) {
      const inner = token.slice(1, -1)
      nodes.push(
        <code
          key={k}
          className={cn(
            'rounded px-1.5 py-0.5 font-mono text-xs',
            isUser ? 'bg-primary-foreground/15 text-primary-foreground' : 'bg-muted text-lime',
          )}
        >
          {inner}
        </code>,
      )
    } else {
      nodes.push(token)
    }

    lastIndex = tokenRegex.lastIndex
  }

  if (lastIndex < line.length) {
    nodes.push(line.slice(lastIndex))
  }

  return nodes.length > 0 ? nodes : line
}

function FormattedChatText({ text, isUser }: { text: string; isUser: boolean }) {
  const lines = text.split('\n')

  return (
    <div className="flex flex-col gap-1.5 break-words">
      {lines.map((rawLine, idx) => {
        const line = rawLine.trimEnd()
        const key = `line-${idx}`

        if (!line.trim()) {
          return <div key={key} className="h-1.5" aria-hidden="true" />
        }

        if (/^---+$|^\*\*\*+$/.test(line.trim())) {
          return <hr key={key} className="my-1.5 border-border/60" />
        }

        const headingMatch = /^(#{1,4})\s+(.+)$/.exec(line.trim())
        if (headingMatch) {
          const level = headingMatch[1].length
          const content = headingMatch[2]
          return (
            <div
              key={key}
              className={cn(
                'mt-1.5 font-bold [font-synthesis:weight] [-webkit-text-stroke:0.35px_currentColor]',
                level <= 2 ? 'text-base text-lime' : 'text-sm text-lime',
              )}
            >
              {renderInlineMarkdown(content, key, isUser)}
            </div>
          )
        }

        const quoteMatch = /^>\s*(.+)$/.exec(line.trim())
        if (quoteMatch) {
          return (
            <blockquote
              key={key}
              className="my-0.5 rounded-r-lg border-l-2 border-lime/70 bg-lime/10 py-1.5 pl-3 pr-2 text-sm"
            >
              {renderInlineMarkdown(quoteMatch[1], key, isUser)}
            </blockquote>
          )
        }

        const bulletMatch = /^(\s*)([*\-•])\s+(.+)$/.exec(line)
        if (bulletMatch) {
          return (
            <div key={key} className="flex items-start gap-2 pl-1">
              <span
                className={cn(
                  'mt-1.5 size-1.5 shrink-0 rounded-full',
                  isUser ? 'bg-primary-foreground' : 'bg-lime',
                )}
                aria-hidden="true"
              />
              <div className="min-w-0 flex-1">
                {renderInlineMarkdown(bulletMatch[3], key, isUser)}
              </div>
            </div>
          )
        }

        const numberedMatch = /^(\s*)(\d+[.)])\s+(.+)$/.exec(line)
        if (numberedMatch) {
          return (
            <div key={key} className="flex items-start gap-2 pl-0.5">
              <span
                className={cn(
                  'shrink-0 font-mono text-xs font-bold mt-0.5',
                  isUser ? 'text-primary-foreground' : 'text-lime',
                )}
              >
                {numberedMatch[2]}
              </span>
              <div className="min-w-0 flex-1">
                {renderInlineMarkdown(numberedMatch[3], key, isUser)}
              </div>
            </div>
          )
        }

        return (
          <div key={key} className="whitespace-pre-wrap">
            {renderInlineMarkdown(line, key, isUser)}
          </div>
        )
      })}
    </div>
  )
}

function buildDefaultThreads(): Record<ChatRole, ChatTurnMessage[]> {
  const now = Date.now()
  return {
    usthad: [
      {
        id: 'welcome-usthad',
        role: 'model',
        text: PERSONAS[0].welcomeMessage,
        timestamp: now,
        modelUsed: 'gemini-3.1-flash-lite',
        persona: 'usthad',
      },
    ],
    academic: [
      {
        id: 'welcome-academic',
        role: 'model',
        text: PERSONAS[1].welcomeMessage,
        timestamp: now,
        modelUsed: 'gemini-3.1-flash-lite',
        persona: 'academic',
      },
    ],
    language: [
      {
        id: 'welcome-language',
        role: 'model',
        text: PERSONAS[2].welcomeMessage,
        timestamp: now,
        modelUsed: 'gemini-3.1-flash-lite',
        persona: 'language',
      },
    ],
    campus: [
      {
        id: 'welcome-campus',
        role: 'model',
        text: PERSONAS[3].welcomeMessage,
        timestamp: now,
        modelUsed: 'gemini-3.1-flash-lite',
        persona: 'campus',
      },
    ],
  }
}

export function GeminiChatbot({ student }: { student: Student }) {
  const [role, setRole] = useState<ChatRole>('usthad')
  const [language, setLanguage] = useState<ChatLanguage>('ml')
  const [modelTier, setModelTier] = useState<ChatModelTier>('flash-lite')
  const [threads, setThreads] = useState<Record<ChatRole, ChatTurnMessage[]>>(buildDefaultThreads)
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [savedId, setSavedId] = useState<string | null>(null)
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null)

  const threadContainerRef = useRef<HTMLDivElement | null>(null)

  const currentPersona = useMemo(
    () => PERSONAS.find((p) => p.id === role) ?? PERSONAS[0],
    [role],
  )

  const currentMessages = useMemo(() => threads[role] ?? [], [threads, role])

  const safeStudentId = useMemo(() => sanitizeId(student.id), [student.id])
  const activeUid = useMemo(
    () => (firebaseUser ? firebaseUser.uid : `portal_${safeStudentId}`),
    [firebaseUser, safeStudentId],
  )

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setFirebaseUser(user)
    })
    return () => unsubscribe()
  }, [])

  // Load saved threads from localStorage
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(CHAT_STORAGE_KEY)
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<Record<ChatRole, ChatTurnMessage[]>>
        if (parsed && typeof parsed === 'object') {
          setThreads((prev) => ({
            usthad: Array.isArray(parsed.usthad) && parsed.usthad.length > 0 ? parsed.usthad : prev.usthad,
            academic:
              Array.isArray(parsed.academic) && parsed.academic.length > 0 ? parsed.academic : prev.academic,
            language:
              Array.isArray(parsed.language) && parsed.language.length > 0 ? parsed.language : prev.language,
            campus: Array.isArray(parsed.campus) && parsed.campus.length > 0 ? parsed.campus : prev.campus,
          }))
        }
      }
    } catch {
      // Ignore storage errors
    }
  }, [])

  // Persist threads on update
  useEffect(() => {
    try {
      window.localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(threads))
    } catch {
      // Ignore quota errors
    }
  }, [threads])

  // Scroll thread container to bottom when messages change
  useEffect(() => {
    const el = threadContainerRef.current
    if (el) {
      el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' })
    }
  }, [currentMessages, sending])

  async function handleSendMessage(customText?: string) {
    const textToSend = (customText ?? input).trim()
    if (!textToSend || sending) return

    if (!customText) {
      setInput('')
    }

    setErrorMessage(null)

    const userMsg: ChatTurnMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: textToSend,
      timestamp: Date.now(),
      persona: role,
    }

    const previousHistory = currentMessages.map((m) => ({
      role: m.role,
      text: m.text,
    }))

    setThreads((prev) => ({
      ...prev,
      [role]: [...(prev[role] ?? []), userMsg],
    }))

    setSending(true)

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend.slice(0, 2000),
          history: previousHistory,
          role,
          language,
          modelTier,
          studentName: student.name,
          studentClass: student.className,
        }),
      })

      const data = await res.json()
      if (!res.ok) {
        throw new Error(data.error || 'Failed to get response from Gemini chatbot.')
      }

      const botMsg: ChatTurnMessage = {
        id: `model-${Date.now()}`,
        role: 'model',
        text: String(data.reply ?? ''),
        timestamp: Date.now(),
        modelUsed: String(data.modelUsed ?? (modelTier === 'flash-lite' ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash')),
        persona: role,
      }

      setThreads((prev) => ({
        ...prev,
        [role]: [...(prev[role] ?? []), botMsg],
      }))
    } catch (err) {
      setErrorMessage(
        err instanceof Error
          ? err.message
          : 'സെർവർ തിരക്ക് കാരണം മറുപടി ലഭിച്ചില്ല. ദയവായി വീണ്ടും ശ്രമിക്കുക.',
      )
    } finally {
      setSending(false)
    }
  }

  function handleResetThread() {
    const defaultForRole = buildDefaultThreads()[role]
    setThreads((prev) => ({
      ...prev,
      [role]: defaultForRole,
    }))
    setErrorMessage(null)
  }

  function handleCopyMessage(msg: ChatTurnMessage) {
    void navigator.clipboard.writeText(msg.text)
    setCopiedId(msg.id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  async function handleSaveTurnToNotebook(modelMsg: ChatTurnMessage, index: number) {
    // Find the preceding user message if available
    let promptText = `${currentPersona.title} — Conversation Note`
    for (let i = index - 1; i >= 0; i--) {
      if (currentMessages[i]?.role === 'user') {
        promptText = currentMessages[i].text
        break
      }
    }

    const cleanPrompt = promptText.trim().slice(0, 2000)
    const cleanResponse = modelMsg.text.trim().slice(0, 15000)
    if (!cleanPrompt || !cleanResponse) return

    const noteId = sanitizeId(`note_${safeStudentId}_${Date.now()}`)
    const mappedMode =
      role === 'usthad'
        ? 'kitab'
        : role === 'academic'
          ? 'qa'
          : role === 'language'
            ? 'translation'
            : 'dawa'

    const path = `studyNotes/${noteId}`
    try {
      await setDoc(doc(db, 'studyNotes', noteId), {
        uid: activeUid,
        studentId: safeStudentId,
        mode: mappedMode,
        language,
        prompt: cleanPrompt,
        response: cleanResponse,
        createdAt: serverTimestamp(),
      })
      setSavedId(modelMsg.id)
      setTimeout(() => setSavedId(null), 2500)
    } catch (error) {
      try {
        handleFirestoreError(error, OperationType.CREATE, path)
      } catch {
        // Logged by handleFirestoreError
      }
    }
  }

  const turnCount = Math.max(0, currentMessages.filter((m) => m.role === 'user').length)

  return (
    <Panel
      id="gemini-chatbot"
      eyebrow="Multi-Turn Conversational AI"
      title="Da'wa College Chatbot"
      icon={MessageSquareText}
      className="border-lime/30"
      action={
        <div className="flex w-full flex-wrap items-center justify-between gap-2 sm:w-auto sm:justify-end">
          <div
            role="group"
            aria-label="Select Gemini model tier"
            className="inline-flex max-w-full flex-wrap rounded-xl border border-border bg-background/70 p-1"
          >
            {MODEL_TIERS.map((tier) => {
              const active = modelTier === tier.id
              return (
                <button
                  key={tier.id}
                  type="button"
                  onClick={() => setModelTier(tier.id)}
                  title={`${tier.label} (${tier.description})`}
                  className={cn(
                    'inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap',
                    active
                      ? 'bg-lime text-primary-foreground font-semibold shadow-xs'
                      : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  <tier.icon className="size-3.5 shrink-0" aria-hidden="true" />
                  <span>{tier.label}</span>
                </button>
              )
            })}
          </div>

          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleResetThread}
            disabled={sending || currentMessages.length <= 1}
            className="h-8 gap-1.5 rounded-lg px-2.5 text-xs whitespace-nowrap shrink-0"
          >
            <RotateCcw className="size-3.5" aria-hidden="true" />
            New Chat
          </Button>
        </div>
      }
    >
      <div className="grid min-w-0 gap-6 lg:grid-cols-12">
        {/* Left Sidebar: Chatbot Roles (System Instructions) & Language Controls */}
        <div className="flex min-w-0 flex-col justify-between gap-4 lg:col-span-4">
          <div className="flex min-w-0 flex-col gap-3">
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Select Chatbot Personal
              </p>
              <span className="font-mono text-xs text-lime tabular-nums shrink-0">
                {turnCount} {turnCount === 1 ? 'turn' : 'turns'}
              </span>
            </div>

            <div className="grid min-w-0 grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-1">
              {PERSONAS.map((persona) => {
                const active = role === persona.id
                const msgCount = Math.max(
                  0,
                  (threads[persona.id] ?? []).filter((m) => m.role === 'user').length,
                )
                return (
                  <button
                    key={persona.id}
                    type="button"
                    onClick={() => {
                      setRole(persona.id)
                      setErrorMessage(null)
                    }}
                    className={cn(
                      'flex min-w-0 flex-col items-start gap-1 rounded-xl border p-3.5 text-left transition-all duration-200',
                      active
                        ? 'border-lime/60 bg-lime/10 shadow-xs'
                        : 'border-border bg-background/50 hover:border-lime/30 hover:bg-muted/50',
                    )}
                  >
                    <div className="flex w-full min-w-0 items-center justify-between gap-2">
                      <span className="flex min-w-0 items-center gap-2 text-xs font-semibold text-foreground">
                        <persona.icon
                          className={cn('size-4 shrink-0', active ? 'text-lime' : 'text-muted-foreground')}
                          aria-hidden="true"
                        />
                        <span className="truncate">{persona.title}</span>
                      </span>
                      {msgCount > 0 ? (
                        <span className="shrink-0 rounded-md bg-lime/15 px-1.5 py-0.5 font-mono text-[10px] font-semibold text-lime">
                          {msgCount}
                        </span>
                      ) : null}
                    </div>
                    <p className="w-full break-words text-xs font-medium text-lime/90">{persona.malayalamTitle}</p>
                    <p className="line-clamp-2 w-full break-words text-[11px] leading-relaxed text-muted-foreground">
                      {persona.description}
                    </p>
                  </button>
                )
              })}
            </div>
          </div>

          {/* Language & Active System Instruction Summary */}
          <div className="flex min-w-0 flex-col gap-3 rounded-xl border border-border bg-background/50 p-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-medium text-muted-foreground">Response Language:</span>
              <div
                role="group"
                aria-label="Chatbot output language"
                className="inline-flex max-w-full flex-wrap rounded-lg border border-border bg-background p-0.5"
              >
                {LANGUAGES.map((lang) => (
                  <button
                    key={lang.id}
                    type="button"
                    onClick={() => setLanguage(lang.id)}
                    className={cn(
                      'rounded-md px-2 py-1 text-xs font-medium transition-colors whitespace-nowrap',
                      language === lang.id
                        ? 'bg-primary text-primary-foreground font-semibold'
                        : 'text-muted-foreground hover:text-foreground',
                    )}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="border-t border-border/60 pt-2.5 text-[11px] leading-relaxed text-muted-foreground">
              <span className="font-semibold text-foreground">Active System Role: </span>
              {currentPersona.title} ({currentPersona.badge}) · Maintains multi-turn memory across your conversation.
            </div>
          </div>
        </div>

        {/* Right Column: Scrollable Conversation Thread & Composer */}
        <div className="flex min-w-0 flex-col overflow-hidden rounded-2xl border border-border bg-background/60 lg:col-span-8">
          {/* Thread Header */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-4 py-3">
            <div className="flex min-w-0 items-center gap-2.5">
              <div className="flex size-8 shrink-0 items-center justify-center rounded-xl bg-lime/15 text-lime">
                <currentPersona.icon className="size-4" aria-hidden="true" />
              </div>
              <div className="min-w-0">
                <h3 className="break-words text-sm font-semibold text-foreground">
                  {currentPersona.title}{' '}
                  <span className="font-normal text-muted-foreground">
                    · {currentPersona.malayalamTitle}
                  </span>
                </h3>
                <p className="text-[11px] text-muted-foreground">
                  Multi-turn thread · Context preserved across messages
                </p>
              </div>
            </div>

            <span className="font-mono text-[11px] text-lime">
              {modelTier === 'flash-lite' ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash'}
            </span>
          </div>

          {/* Scrollable Messages Container */}
          <div
            ref={threadContainerRef}
            className="flex h-[420px] flex-col gap-4 overflow-y-auto p-4 md:p-5"
            aria-live="polite"
          >
            {currentMessages.map((msg, idx) => {
              const isUser = msg.role === 'user'
              return (
                <div
                  key={msg.id}
                  className={cn(
                    'flex gap-3',
                    isUser ? 'flex-row-reverse' : 'flex-row',
                  )}
                >
                  <div
                    className={cn(
                      'flex size-8 shrink-0 items-center justify-center rounded-xl border',
                      isUser
                        ? 'border-primary/40 bg-primary text-primary-foreground'
                        : 'border-lime/30 bg-lime/15 text-lime',
                    )}
                    aria-hidden="true"
                  >
                    {isUser ? <User className="size-4" /> : <Bot className="size-4" />}
                  </div>

                  <div
                    className={cn(
                      'flex max-w-[85%] flex-col gap-2 rounded-2xl border px-4 py-3 text-sm leading-relaxed',
                      isUser
                        ? 'border-primary/30 bg-primary text-primary-foreground'
                        : 'border-border bg-card/90 text-foreground',
                    )}
                  >
                    <FormattedChatText text={msg.text} isUser={isUser} />

                    <div
                      className={cn(
                        'mt-1 flex flex-wrap items-center justify-between gap-3 border-t pt-2 text-[10px]',
                        isUser
                          ? 'border-primary-foreground/15 text-primary-foreground/75'
                          : 'border-border/60 text-muted-foreground',
                      )}
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-mono tabular-nums">
                          {new Date(msg.timestamp).toLocaleTimeString('en-IN', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                        {!isUser && msg.modelUsed ? (
                          <span className="font-mono text-lime">{msg.modelUsed}</span>
                        ) : null}
                      </div>

                      {!isUser ? (
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleCopyMessage(msg)}
                            className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                          >
                            {copiedId === msg.id ? (
                              <>
                                <Check className="size-3 text-lime" aria-hidden="true" />
                                Copied
                              </>
                            ) : (
                              <>
                                <Copy className="size-3" aria-hidden="true" />
                                Copy
                              </>
                            )}
                          </button>

                          {msg.id && !msg.id.startsWith('welcome-') ? (
                            <button
                              type="button"
                              onClick={() => void handleSaveTurnToNotebook(msg, idx)}
                              className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[11px] font-medium text-lime transition-colors hover:bg-lime/15"
                            >
                              {savedId === msg.id ? (
                                <>
                                  <BookmarkCheck className="size-3" aria-hidden="true" />
                                  Saved to Notebook
                                </>
                              ) : (
                                <>
                                  <Bookmark className="size-3" aria-hidden="true" />
                                  Save Note
                                </>
                              )}
                            </button>
                          ) : null}
                        </div>
                      ) : null}
                    </div>
                  </div>
                </div>
              )
            })}

            {sending ? (
              <div className="flex items-start gap-3">
                <div className="flex size-8 shrink-0 items-center justify-center rounded-xl border border-lime/30 bg-lime/15 text-lime">
                  <Loader2 className="size-4 animate-spin" aria-hidden="true" />
                </div>
                <div className="flex flex-col gap-2 rounded-2xl border border-border bg-card/80 px-4 py-3 text-xs text-muted-foreground">
                  <span className="font-medium text-foreground">
                    {currentPersona.title} is thinking...
                  </span>
                  <span>മറുപടി തയ്യാറാക്കുന്നു · Analyzing conversation history</span>
                </div>
              </div>
            ) : null}
          </div>

          {/* Starter Prompts Bar */}
          <div className="border-t border-border/70 bg-background/40 px-4 py-2.5">
            <div className="flex items-center gap-2 overflow-x-auto pb-0.5">
              <span className="shrink-0 text-[11px] font-semibold text-muted-foreground">
                Try asking:
              </span>
              {currentPersona.starters.map((starter) => (
                <button
                  key={starter.label}
                  type="button"
                  disabled={sending}
                  onClick={() => void handleSendMessage(starter.prompt)}
                  className="shrink-0 rounded-lg border border-border bg-background/80 px-2.5 py-1 text-xs font-medium text-foreground/90 transition-colors hover:border-lime/50 hover:bg-lime/10 disabled:opacity-50"
                >
                  {starter.label}
                </button>
              ))}
            </div>
          </div>

          {/* Error Banner if any */}
          {errorMessage ? (
            <div
              role="alert"
              className="mx-4 mt-2 flex items-center justify-between gap-2 rounded-xl border border-destructive/40 bg-destructive/10 px-3.5 py-2 text-xs text-destructive"
            >
              <span>{errorMessage}</span>
              <button
                type="button"
                onClick={() => setErrorMessage(null)}
                className="font-semibold underline whitespace-nowrap shrink-0"
              >
                Dismiss
              </button>
            </div>
          ) : null}

          {/* Message Input Composer */}
          <form
            onSubmit={(e) => {
              e.preventDefault()
              void handleSendMessage()
            }}
            className="flex items-end gap-2.5 border-t border-border p-3.5 md:p-4"
          >
            <label htmlFor="gemini-chatbot-input" className="sr-only">
              Type your message to the Da&apos;wa College Gemini Chatbot
            </label>
            <textarea
              id="gemini-chatbot-input"
              rows={2}
              maxLength={2000}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  void handleSendMessage()
                }
              }}
              placeholder={`${currentPersona.malayalamTitle} ചാറ്റ്ബോട്ടിനോട് ചോദിക്കുക... (Press Enter to send, Shift+Enter for new line)`}
              className={cn(
                fieldClassName,
                'h-auto min-h-[52px] max-h-32 flex-1 resize-y py-2.5 text-sm leading-relaxed',
              )}
            />
            <Button
              type="submit"
              disabled={sending || !input.trim()}
              className="h-[52px] gap-2 rounded-xl px-5 font-semibold whitespace-nowrap shrink-0"
            >
              {sending ? (
                <Loader2 className="size-4 animate-spin" aria-hidden="true" />
              ) : (
                <Send className="size-4" aria-hidden="true" />
              )}
              <span>Send</span>
            </Button>
          </form>
        </div>
      </div>
    </Panel>
  )
}
